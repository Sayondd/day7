﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using SF2024User11Lib;

namespace UnitTestLibrary
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AvailablePeriods_NoConsultations()
        {
            TimeSpan[] startTimes = new TimeSpan[0];
            int[] durations = new int[0];
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(15, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("09:00-15:00", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_SingleConsultationAtBeginningOfDay()
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 30, 0) };
            int[] durations = { 30 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(2, result.Length);
            Assert.AreEqual("09:00-09:30", result[0]);
            Assert.AreEqual("10:00-17:00", result[1]);
        }
        [TestMethod]
        public void AvailablePeriods_ConsultationsCoverWholeDay()//консультации целый день
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0), new TimeSpan(11, 0, 0), new TimeSpan(13, 0, 0) };
            int[] durations = { 120, 360, 360 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(0, result.Length);
        }
        [TestMethod]
        public void AvailablePeriods_MultipleConsultations()
        {
            TimeSpan[] startTimes = { new TimeSpan(10, 0, 0), new TimeSpan(13, 0, 0) };
            int[] durations = { 60, 45 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(3, result.Length);
            Assert.AreEqual("09:00-10:00", result[0]);
            Assert.AreEqual("11:00-13:00", result[1]);
            Assert.AreEqual("13:45-17:00", result[2]);
        }
        [TestMethod]
        public void AvailablePeriods_SingleConsultationAtEndOfDay()
        {
            TimeSpan[] startTimes = { new TimeSpan(16, 40, 0) };
            int[] durations = { 10 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 20;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("09:00-16:40", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_ConsultationEndsExactlyAtEndOfWorkingDay()
        {
            TimeSpan[] startTimes = { new TimeSpan(16, 30, 0) };
            int[] durations = { 30 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("09:00-16:30", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_NoConsultationsAndShorterWorkingDay()
        {
            TimeSpan[] startTimes = { };
            int[] durations = { };
            TimeSpan beginWorkingTime = new TimeSpan(09, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(14, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("09:00-14:00", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_ConsultationsOverlap()
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0), new TimeSpan(9, 30, 0), new TimeSpan(10, 0, 0) };
            int[] durations = { 60, 30, 45 };
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(12, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(2, result.Length);
            Assert.AreEqual("08:00-09:00", result[0]);
            Assert.AreEqual("10:45-12:00", result[1]);
        }
        [TestMethod]
        public void AvailablePeriods_ConsultationsDoNotOverlap()
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0), new TimeSpan(10, 0, 0), new TimeSpan(13, 0, 0) };
            int[] durations = { 60, 30, 45 };
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(14, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(2, result.Length);
            Assert.AreEqual("08:00-09:00", result[0]);
            Assert.AreEqual("10:30-13:00", result[1]);
        }
        [TestMethod]
        public void AvailablePeriods_NoAvailableSlots_ReturnsEmptyArray()//все время занято
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0), new TimeSpan(10, 0, 0), new TimeSpan(11, 0, 0) };
            int[] durations = { 60, 60, 120 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(13, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(0, result.Length);
        }
    }
}
