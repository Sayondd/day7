﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Магазин
{
    /// <summary>
    /// Логика взаимодействия для addProduct.xaml
    /// </summary>
    public partial class addProduct : Window
    {
        public addProduct()
        {
            InitializeComponent();
            cbCategory.ItemsSource = App.entities.Categories.
                Select(c => c.CategoryName).ToList();
            cbManufacturer.ItemsSource = App.entities.Manufactureds.
                Select(c => c.ManufacturedName).ToList();
            cbSupplier.ItemsSource = App.entities.Suppliers.
                Select(c => c.SuppliersName).ToList();
            cbUnitOfMeasurement.ItemsSource = App.entities.Units.
                Select(c => c.UnitName).ToList();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tbArticle.Text == "" | tbName.Text == "" |
                    tbDescription.Text == "" | cbCategory.Text == ""
                    | cbManufacturer.Text == ""
                    | tbCost.Text == "" | tbDescription.Text == ""
                    | tbQuantityInStock.Text == "" |
                    tbMaxDiscount.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    int categoryID = App.entities.Categories.
                        Where(x => x.CategoryName == cbCategory.Text).
                        Select(x => x.idCategory).FirstOrDefault();
                    int manufacturerID = App.entities.Manufactureds.
                        Where(x => x.ManufacturedName == cbManufacturer.Text).
                        Select(x => x.idManufactured).FirstOrDefault();
                    int unitOfMeasurrementID = App.entities.Units.
                        Where(x => x.UnitName == cbUnitOfMeasurement.Text).
                        Select(x => x.idUnit).FirstOrDefault();
                    int suppliersID = App.entities.Suppliers.
                        Where(x => x.SuppliersName == cbSupplier.Text).
                        Select(x => x.idSuppliers).FirstOrDefault();
                    bd.Product product = new bd.Product()
                    {
                        ProductArticleNumber = tbArticle.Text,
                        ProductName = tbName.Text,
                        Description = tbDescription.Text,
                        idCategory = categoryID,
                        idManufactured = manufacturerID,
                        Price = Convert.ToDecimal(tbCost.Text),
                        CurrentDiscount = Convert.ToInt32(tbDiscount.Text),
                        QuantityStock = Convert.ToInt32(tbQuantityInStock.Text),
                        MaximumDiscountSize = Convert.ToInt32(tbMaxDiscount.Text),
                        idSuppliers = suppliersID
                    };
                    App.entities.Products.Add(product);
                    App.entities.SaveChanges();
                    MessageBox.Show("Данные успешно добавлены!");
                    this.Close();
                }

            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат!");
            }
        }
    }
}
